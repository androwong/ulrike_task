iraq=[
  {
    "ID": 1,
    "Text": "Lockheed Martin - Fort Worth",
    "Company": "Lockheed Martin",
    "Latitude": 32.772114,
    "Longitude": -97.445133,
    "Country": "United States",
    "ThemesString": "Aircraft Production Line",
    "MainTheme": "Aircraft Production Line"
  },
  {
    "ID": 2,
    "Text": "Lockheed Martin - Marietta",
    "Company": "Lockheed Martin",
    "Latitude": 33.927443,
    "Longitude": -84.531967,
    "Country": "United States",
    "ThemesString": "Aircraft Section Production",
    "MainTheme": "Aircraft Section Production"
  },
  {
    "ID": 3,
    "Text": "Lockheed Martin - Palmdale",
    "Company": "Lockheed Martin",
    "Latitude": 34.613531,
    "Longitude": -118.113303,
    "Country": "United States",
    "ThemesString": "Aircraft Design",
    "MainTheme": "Aircraft Design"
  },
  {
    "ID": 4,
    "Text": "Lockheed Martin - Pike County",
    "Company": "Lockheed Martin",
    "Latitude": 31.971001,
    "Longitude": -85.987607,
    "Country": "United States",
    "ThemesString": "Missile Production",
    "MainTheme": "Missile Production"
  },
  {
    "ID": 5,
    "Text": "Lockheed Martin - East Camden",
    "Company": "Lockheed Martin",
    "Latitude": 33.623452,
    "Longitude": -92.720481,
    "Country": "United States",
    "ThemesString": "Missile Production",
    "MainTheme": "Missile Production"
  },
  {
    "ID": 6,
    "Text": "Lockheed Martin - Middle River",
    "Company": "Lockheed Martin",
    "Latitude": 39.329602,
    "Longitude": -76.429813,
    "Country": "United States",
    "ThemesString": "Missile Launcher Production",
    "MainTheme": "Missile Launcher Production"
  },
  {
    "ID": 7,
    "Text": "Lockheed Martin UK - Ampthill",
    "Company": "Lockheed Martin",
    "Latitude": 52.045613,
    "Longitude": -0.495065,
    "Country": "United Kingdom",
    "ThemesString": "Armoured Vehicle Upgrade",
    "MainTheme": "Armoured Vehicle Upgrade"
  },
  {
    "ID": 8,
    "Text": "Lockheed Martin - Sunnyvale",
    "Company": "Lockheed Martin",
    "Latitude": 37.415924,
    "Longitude": -122.036099,
    "Country": "United States",
    "ThemesString": "Satellites",
    "MainTheme": "Satellites"
  },
  {
    "ID": 9,
    "Text": "Lockheed Martin - Littleton",
    "Company": "Lockheed Martin",
    "Latitude": 39.49373,
    "Longitude": -105.106838,
    "Country": "United States",
    "ThemesString": "Satellites",
    "MainTheme": "Satellites"
  },
  {
    "ID": 10,
    "Text": "Lockheed Martin - Greenville",
    "Company": "Lockheed Martin",
    "Latitude": 34.745299,
    "Longitude": -82.379546,
    "Country": "United States",
    "ThemesString": "Aircraft Production Line",
    "MainTheme": "Aircraft Production Line"
  }
]
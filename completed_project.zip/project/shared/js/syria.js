syria=[
  {
    "Name": "Syria1",
    "Date": "06/12/2017",
    "Description": "The SOHR says that Russian airstrikes on the ISIS-...The SOHR says that Russian airstrikes on the ISIS-testing more text testing more text",
    "Comment": "Armed clashes",
    "Type": "Armed clashes",
    "Latitude": 31.842794,
    "Longitude": 37.1343,
    "Count": 24
  },
  {
    "Name": "Syri2a",
    "Date": "05/12/2017",
    "Description": "The Homs police chief says that a bombing on a bus...The SOHR says that Russian airstrikes on the ISIS-testing more text testing more text",
    "Comment": "Insurgency",
    "Type": "Human security",
    "Latitude": 32.2021,
    "Longitude": 36.390302,
    "Count": 12
  },
  {
    "Name": "Syria3",
    "Date": "06/12/2017",
    "Description": "Col Ryan Dillon, the spokesman for the US-led coal...The SOHR says that Russian airstrikes on the ISIS-testing more text testing more text",
    "Comment": "Grenade",
    "Type": "Armed clashes",
    "Latitude": 30.2021,
    "Longitude": 36.235324,
    "Count": 12
  },
  {
    "Name": "Syria4",
    "Date": "07/12/2017",
    "Description": "Col Ryan Dillon, the spokesman for the US-led coal...The SOHR says that Russian airstrikes on the ISIS-testing more text testing more text",
    "Comment": "Human security",
    "Type": "Human security",
    "Latitude": 34.2021,
    "Longitude": 37.1343,
    "Count": 12
  },
  {
    "Name": "Syria5",
    "Date": "08/12/2017",
    "Description": "Col Ryan Dillon, the spokesman for the US-led coal...The SOHR says that Russian airstrikes on the ISIS-testing more text testing more text",
    "Comment": "Kidnap",
    "Type": "Insurgency",
    "Latitude": 34.842794,
    "Longitude": 32.1343,
    "Count": 12
  },
  {
    "Name": "Syria6",
    "Date": "09/12/2017",
    "Description": "Col Ryan Dillon, the spokesman for the US-led coal...The SOHR says that Russian airstrikes on the ISIS-testing more text testing more text",
    "Comment": "Armed clashes",
    "Type": "Armed clashes",
    "Latitude": 34.842794,
    "Longitude": 36.730342,
    "Count": 12
  },
  {
    "Name": "Syria7",
    "Date": "10/12/2017",
    "Description": "Col Ryan Dillon, the spokesman for the US-led coal...The SOHR says that Russian airstrikes on the ISIS-testing more text testing more text",
    "Comment": "Human security",
    "Type": "Human security",
    "Latitude": 33.570505,
    "Longitude": 36.235324,
    "Count": 12
  },
  {
    "Name": "Syria9",
    "Date": "11/12/2017",
    "Description": "Col Ryan Dillon, the spokesman for the US-led coal...The SOHR says that Russian airstrikes on the ISIS-testing more text testing more text",
    "Comment": "Insurgency",
    "Type": "Insurgency",
    "Latitude": 33.13919,
    "Longitude": 36.946443,
    "Count": 12
  },
  {
    "Name": "Syria9",
    "Date": "12/12/2017",
    "Description": "Col Ryan Dillon, the spokesman for the US-led coal...The SOHR says that Russian airstrikes on the ISIS-testing more text testing more text",
    "Comment": "Armed clashes",
    "Type": "Armed clashes",
    "Latitude": 37.528337,
    "Longitude": 31.390302,
    "Count": 12
  },
  {
    "Name": "Syria10",
    "Date": "13/12/2017",
    "Description": "Col Ryan Dillon, the spokesman for the US-led coal...The SOHR says that Russian airstrikes on the ISIS-testing more text testing more text",
    "Comment": "Human security",
    "Type": "Human security",
    "Latitude": 32.842794,
    "Longitude": 38.730342,
    "Count": 12
  },
  {
    "Name": "Syria11",
    "Date": "14/12/2017",
    "Description": "Col Ryan Dillon, the spokesman for the US-led coal...The SOHR says that Russian airstrikes on the ISIS-testing more text testing more text",
    "Comment": "Insurgency",
    "Type": "Insurgency",
    "Latitude": 29.570505,
    "Longitude": 36.235324,
    "Count": 12
  },
  {
    "Name": "Syria12",
    "Date": "15/12/2017",
    "Description": "Col Ryan Dillon, the spokesman for the US-led coal...The SOHR says that Russian airstrikes on the ISIS-testing more text testing more text",
    "Comment": "Armed clashes",
    "Type": "Armed clashes",
    "Latitude": 33.513919,
    "Longitude": 30.346443,
    "Count": 12
  },
  {
    "Name": "Syria13",
    "Date": "16/12/2017",
    "Description": "Col Ryan Dillon, the spokesman for the US-led coal...The SOHR says that Russian airstrikes on the ISIS-testing more text testing more text",
    "Comment": "Human security",
    "Type": "Human security",
    "Latitude": 30.928337,
    "Longitude": 36.90302,
    "Count": 12
  },
  {
    "Name": "Syria14",
    "Date": "17/12/2017",
    "Description": "Col Ryan Dillon, the spokesman for the US-led coal...The SOHR says that Russian airstrikes on the ISIS-testing more text testing more text",
    "Comment": "Insurgency",
    "Type": "Insurgency",
    "Latitude": 34.842794,
    "Longitude": 36.730342,
    "Count": 12
  }
]
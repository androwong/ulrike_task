syria = [
 {
   "Conflict": "Obs Tower",
   "Date": "Obs Tower",
   "Text": "Obs Tower",
   "Tag": "Obs Tower",
   "Tags": "Obs Tower",
   "Latitude": 9.5408935,
   "Longitude": 112.8803596,
   "Fatalities": 6
 },
 {
   "Conflict": "Obs Tower",
   "Date": "Obs Tower",
   "Text": "Obs Tower",
   "Tag": "Obs Tower",
   "Tags": "Obs Tower",
   "Latitude": 9.5399413,
   "Longitude": 112.8785035,
   "Fatalities": 6
 },
 {
   "Conflict": "Obs Tower",
   "Date": "Obs Tower",
   "Text": "Obs Tower",
   "Tag": "Obs Tower",
   "Tags": "Obs Tower",
   "Latitude": 9.550048,
   "Longitude": 112.897106,
   "Fatalities": 13
 },
 {
   "Conflict": "Obs Tower",
   "Date": "Obs Tower",
   "Text": "Obs Tower",
   "Tag": "Obs Tower",
   "Tags": "Obs Tower",
   "Latitude": 9.555338,
   "Longitude": "112.903828",
   "Fatalities": 6
 },
 {
   "Conflict": "Golf ball farm",
   "Date": "Golf ball farm",
   "Text": "Golf ball farm",
   "Tag": "Golf ball farm",
   "Tags": "Golf ball farm",
   "Latitude": 9.559242,
   "Longitude": 112.900603,
   "Fatalities": 13
 },
 {
   "Conflict": "Obs Tower",
   "Date": "Obs Tower",
   "Text": "Obs Tower",
   "Tag": "Obs Tower",
   "Tags": "Obs Tower",
   "Latitude": 9.559322,
   "Longitude": 112.898801,
   "Fatalities": 13
 },
 {
   "Conflict": "radome",
   "Date": "radome",
   "Text": "radome",
   "Tag": "radome",
   "Tags": "radome",
   "Latitude": 8.862311,
   "Longitude": 112.830207,
   "Fatalities": 6
 },
 {
   "Conflict": "HF Array",
   "Date": "HF Array",
   "Text": "HF Array",
   "Tag": "HF Array",
   "Tags": "HF Array",
   "Latitude": 8.863721,
   "Longitude": "112.829574",
   "Fatalities": 6
 },
 {
   "Conflict": "Obs Tower",
   "Date": "Obs Tower",
   "Text": "Obs Tower",
   "Tag": "Obs Tower",
   "Tags": "Obs Tower",
   "Latitude": 8.865995,
   "Longitude": 112.829343,
   "Fatalities": 13
 },
 {
   "Conflict": "Obs Tower",
   "Date": "Obs Tower",
   "Text": "Obs Tower",
   "Tag": "Obs Tower",
   "Tags": "Obs Tower",
   "Latitude": 8.867299,
   "Longitude": 112.831794,
   "Fatalities": 13
 },
 {
   "Conflict": "Radome",
   "Date": "Radome",
   "Text": "Radome",
   "Tag": "Radome",
   "Tags": "Radome",
   "Latitude": 10.20574,
   "Longitude": 114.224236,
   "Fatalities": 6
 },
 {
   "Conflict": "Obs Tower",
   "Date": "Obs Tower",
   "Text": "Obs Tower",
   "Tag": "Obs Tower",
   "Tags": "Obs Tower",
   "Latitude": 10.209847,
   "Longitude": 114.225432,
   "Fatalities": 6
 },
 {
   "Conflict": "Obs Tower",
   "Date": "Obs Tower",
   "Text": "Obs Tower",
   "Tag": "Obs Tower",
   "Tags": "Obs Tower",
   "Latitude": 9.716491,
   "Longitude": 114.286587,
   "Fatalities": 13
 },
 {
   "Conflict": "Obs Tower",
   "Date": "Obs Tower",
   "Text": "Obs Tower",
   "Tag": "Obs Tower",
   "Tags": "Obs Tower",
   "Latitude": 9.714921,
   "Longitude": 114.288116,
   "Fatalities": 13
 },
 {
   "Conflict": "radome",
   "Date": "radome",
   "Text": "radome",
   "Tag": "radome",
   "Tags": "radome",
   "Latitude": 9.714056,
   "Longitude": 114.287963,
   "Fatalities": 10
 },
 {
   "Conflict": "Obs Towers",
   "Date": "Obs Towers",
   "Text": "Obs Towers",
   "Tag": "Obs Towers",
   "Tags": "Obs Towers",
   "Latitude": 9.898928,
   "Longitude": 115.50012,
   "Fatalities": 10
 },
 {
   "Conflict": "Obs Tower",
   "Date": "Obs Tower",
   "Text": "Obs Tower",
   "Tag": "Obs Tower",
   "Tags": "Obs Tower",
   "Latitude": 9.919637,
   "Longitude": 115.502804,
   "Fatalities": 10
 },
 {
   "Conflict": "Radar",
   "Date": "Radar",
   "Text": "Radar",
   "Tag": "Radar",
   "Tags": "Radar",
   "Latitude": 9.927992,
   "Longitude": 115.511194,
   "Fatalities": 10
 },
 {
   "Conflict": "Obs Tower",
   "Date": "Obs Tower",
   "Text": "Obs Tower",
   "Tag": "Obs Tower",
   "Tags": "Obs Tower",
   "Latitude": 9.923019,
   "Longitude": 115.543209,
   "Fatalities": 20
 },
 {
   "Conflict": "Radome",
   "Date": "Radome",
   "Text": "Radome",
   "Tag": "Radome",
   "Tags": "Radome",
   "Latitude": 9.902666,
   "Longitude": 115.578494,
   "Fatalities": 10
 },
 {
   "Conflict": "Obs Tower",
   "Date": "Obs Tower",
   "Text": "Obs Tower",
   "Tag": "Obs Tower",
   "Tags": "Obs Tower",
   "Latitude": 10.907821,
   "Longitude": 114.067834,
   "Fatalities": 10
 },
 {
   "Conflict": "Obs Tower",
   "Date": "Obs Tower",
   "Text": "Obs Tower",
   "Tag": "Obs Tower",
   "Tags": "Obs Tower",
   "Latitude": 10.9131701,
   "Longitude": 114.060875,
   "Fatalities": 10
 },
 {
   "Conflict": "Obs Tower",
   "Date": "Obs Tower",
   "Text": "Obs Tower",
   "Tag": "Obs Tower",
   "Tags": "Obs Tower",
   "Latitude": 9.908779,
   "Longitude": 114.500608,
   "Fatalities": 20
 },
 {
   "Conflict": "Radome",
   "Date": "Radome",
   "Text": "Radome",
   "Tag": "Radome",
   "Tags": "Radome",
   "Latitude": 9.90808,
   "Longitude": 114.49902,
   "Fatalities": 10
 },
 {
   "Conflict": "Building with radome on",
   "Date": "Building with radome on",
   "Text": "Building with radome on",
   "Tag": "Building with radome on",
   "Tags": "Building with radome on",
   "Latitude": 9.909493,
   "Longitude": 114.496429,
   "Fatalities": 20
 }
]